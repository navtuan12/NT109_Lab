
public class Main {
    public static void main(String[] args){
        //new Bai1();
        //new Bai2();
        //new Bai3();
        //new Bai4();
        //new Bai5();
        //new Bai6();
        //new Bai7();
        //new Bai8();
        //new Bai9();
        //new Bai10();
        //new Bai11();
        //new Bai12();
        //new Bai13();
        //new Bai14();
        new Bai15();
    }
}
